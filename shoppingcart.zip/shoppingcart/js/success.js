	
	var c=localStorage.getItem("check");
	if(c=="2"){
		var y=localStorage.getItem("cust");
		var az =JSON.parse(y);
		$(document).ready(function(){
			$('#name').text(az["name"]);
			$('#addr').text(az["addr"]);
			$('#ordernum').text(az["orderid"]);
			emailjs.send("gmail","template_sLvI4xcE",{"from_name":"Vishal Verma","to_name":"Puneet Kishore","message_html":"Hi "+az["name"]+", Your order has been placed. and your order id is : "+az["orderid"]+". Thanks for using our services"});
			
		});
	}else{	
		$(location).attr('href', 'index.html');		
	}