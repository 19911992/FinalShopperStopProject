	
	var c=localStorage.getItem("check");
	if(c=="0"){
		$(location).attr('href', 'index.html');		
	}else if(c=="2"){
		$(location).attr('href', 'success.html');		
	}else{
		
		var y=localStorage.getItem("cart");
		var az =JSON.parse(y);
	
		var pr=localStorage.getItem("product");
		var x =JSON.parse(pr);
	
	$(document).ready(function(){
		var s=0;
		for(var i=0;i<az.length;i++){
			for(var j=0;j<x.length;j++){
				if(x[j]["id"]==az[i]){
					$('#tablebody').append(
						'<tr id="tr_'+x[j]["id"]+'">'
						+'<td data-th="Product">'
							+'<div class="row">'
								+'<div class="col-sm-2 "><img src="images/'+x[j]["id"]+'.jpg" alt="..." class="img-responsive"/></div>'
								+'<div class="col-sm-10">'
									+'<h4 class="nomargin">'+x[j]["name"]+'</h4>'
									+'<p class="nomargin">'+x[j]["des"]+'</p>'
								+'</div>'
							+'</div>'
						+'</td>'
						+'<td data-th="Price" >$<span id="price_'+x[j]["id"]+'">'+x[j]["price"]+'</span></td>'
						+'<td data-th="Quantity">'
							+'<input type="number" class="form-control text-center id_'+x[j]["id"]+'" id="myqty" name="'+x[j]["id"]+'" value="1">'
						+'</td>'
						+'<td data-th="Subtotal" class="text-center" id="sub_'+x[j]["id"]+'">'+x[j]["price"]+'</td>'
						+'<td class="actions" data-th="">'
							+'<button class="btn btn-danger btn-sm" id="delbtn" name="'+x[j]["id"]+'"><i class="fa fa-trash-o"></i></button>'								
						+'</td>'
					+'</tr>');
					var idm=x[j]["id"];
					var prices=$('#sub_'+idm).text();
					s=s+parseInt(prices);
					
					
				}
			}
		}
		$('#subtotal').text("$"+s);
			var tax=(s*13)/100;
			$('#totaltax').text("$"+tax);
			var buy=parseFloat(tax)+parseFloat(s);
			$('#totalbuy').text("$"+buy);

		$(document.body).on("click","#delbtn",function(){
			var id=$(this).attr("name");
			$('.id_'+id).val("0");
			$('#tr_'+id).hide();
			var removeItem = id;
			az = jQuery.grep(az, function(value) {
				return value != id;
			});
			var xx=JSON.stringify(az);
			localStorage.setItem("cart",xx);
			var s=0
			for(var i=0;i<az.length;i++){
				for(var j=0;j<x.length;j++){
					if(x[j]["id"]==az[i]){
						var idm=x[j]["id"];
						var prices=$('#sub_'+idm).text();
						s=s+parseInt(prices);
					}
				}
			}

			$('#subtotal').text("$"+s);
			var tax=(s*13)/100;
			$('#totaltax').text("$"+tax);
			var buy=parseFloat(tax)+parseFloat(s);
			$('#totalbuy').text("$"+buy);
			
			if(az.length==0){
				$(location).attr('href', 'index.html');
			}
		});
		
		$(document.body).on("keypress","#myqty",function(){
			 return false;
		});
		
		$(document.body).on("click","#myqty",function(){
			if($(this).val()<1){
				$(this).val("1");
			}
			var n=$(this).attr("name");
			var pr=$('#price_'+n).text();
			var qty=$(this).val();
			var tot=pr*qty;
			$('#sub_'+n).text(tot);
			var s=0
			for(var i=0;i<az.length;i++){
				for(var j=0;j<x.length;j++){
					if(x[j]["id"]==az[i]){
						var idm=x[j]["id"];
						var prices=$('#sub_'+idm).text();
						s=s+parseInt(prices);
					}
				}
			}
			
			$('#subtotal').text("$"+s);
			var tax=(s*13)/100;
			$('#totaltax').text("$"+tax);
			var buy=parseFloat(tax)+parseFloat(s);
			$('#totalbuy').text("$"+buy);			
		});

		$("#done").submit(function(){
			var num = Math.floor(Math.random() * 90000) + 10000;			
			var cus={
				"name":$('#name').val(),
				"email":$('#email').val(),
				"phone":$('#phone').val(),
				"addr":$('#addr').val(),
				"orderid":num
				
			}
			$('#ordernum').val(num);
			var cust=JSON.stringify(cus);
			localStorage.setItem("cust",cust);
			localStorage.setItem("check","2");
			$(location).attr('href', 'success.html');
			return false;
		});
	});
}