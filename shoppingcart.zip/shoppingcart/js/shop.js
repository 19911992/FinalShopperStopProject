	
	localStorage.clear();
	localStorage.setItem("check","0");

	var a={
		"id":"1",
		"name":"Check Blue Shirt",
		"price":5,
		"des":"LoremIpsum Product 1 description"
	}
	var b={
		"id":"2",
		"name":"T-Shirt Sports Wear",
		"price":8,
		"des":"LoremIpsum Product 2 description"
		
	}
	var c={
		"id":"3",
		"name":"Line Blue Shirt",
		"price":9,
		"des":"LoremIpsum Product 3 description"
	}
	var d={
		"id":"4",
		"name":"Gym Wear",
		"price":10,
		"des":"LoremIpsum Product 4 description"
	}
	var e={
		"id":"5",
		"name":"Jean",
		"price":15,
		"des":"LoremIpsum Product 5 description"
	}
	
	var cart=[];

	var products=[];
	products.push(a);
	products.push(b);
	products.push(c);
	products.push(d);
	products.push(e);
	
	var x=JSON.stringify(products);
	localStorage.setItem("product",x);
	var y=localStorage.getItem("product");
	var az =JSON.parse(y);
	$(document).ready(function(){
		for(var i=0;i<az.length;i++){
			console.log(az[i]["id"]+" "+az[i]["name"]+" "+az[i]["price"]);
			$('#row').append('<div class="col-sm-4 text-center" id="me">'
			+'<img src="images/'+az[i]["id"]+'.jpg" class="img-rounded"  alt="Cinque Terre" width="304" height="236">' 
			+'<h4>'+az[i]["name"]+'</h4>'
			+'<p>'+az[i]["des"]+'</p>'
			+'<h3>$'+az[i]["price"]+'</h3>'
			+'<a href="javascript:;" class="btn btn-link" id="add_'+az[i]["id"]+'" style="display:none;" value="'+az[i]["id"]+'">Added</a>'
			+'<button type="btn" class="btn btn-primary" id="add" value="'+az[i]["id"]+'">Add To card</button>'
			+'</div>');
		}
		$(document.body).on("click","#add",function(){
			var id=$(this).attr("value");
			cart.push(id);
			$('#add_'+id).show();
			$(this).hide();
			var selectedProduct=JSON.stringify(cart);
			localStorage.setItem("cart",selectedProduct);
			localStorage.setItem("check","1");
	
		});
	});